var game4Json = {
    
NestJson: {"frames": [

{
	"filename": "Symbol 2 instance 10000",
	"frame": {"x":0,"y":0,"w":207,"h":126},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":207,"h":126},
	"sourceSize": {"w":207,"h":126}
}
,{
	"filename": "Symbol 2 instance 10001",
	"frame": {"x":207,"y":0,"w":207,"h":126},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":207,"h":126},
	"sourceSize": {"w":207,"h":126}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Nest.png",
	"format": "RGBA8888",
	"size": {"w":421,"h":142},
	"scale": "1"
}
},
};

