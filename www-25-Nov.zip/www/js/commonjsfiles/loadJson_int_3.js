var game3Json = {

	starAnimJson : {"frames": [

		{
			"filename": "Symbol 10 copy instance 10000",
			"frame": {"x":0,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10001",
			"frame": {"x":0,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10002",
			"frame": {"x":0,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10003",
			"frame": {"x":0,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10004",
			"frame": {"x":33,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10005",
			"frame": {"x":33,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10006",
			"frame": {"x":33,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10007",
			"frame": {"x":33,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10008",
			"frame": {"x":66,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10009",
			"frame": {"x":66,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10010",
			"frame": {"x":66,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10011",
			"frame": {"x":66,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10012",
			"frame": {"x":99,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10013",
			"frame": {"x":99,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10014",
			"frame": {"x":99,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10015",
			"frame": {"x":99,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10016",
			"frame": {"x":132,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10017",
			"frame": {"x":132,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10018",
			"frame": {"x":132,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10019",
			"frame": {"x":132,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10020",
			"frame": {"x":165,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10021",
			"frame": {"x":165,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10022",
			"frame": {"x":165,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10023",
			"frame": {"x":165,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10024",
			"frame": {"x":198,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10025",
			"frame": {"x":198,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10026",
			"frame": {"x":198,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10027",
			"frame": {"x":198,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10028",
			"frame": {"x":231,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10029",
			"frame": {"x":231,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10030",
			"frame": {"x":231,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10031",
			"frame": {"x":231,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10032",
			"frame": {"x":264,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10033",
			"frame": {"x":264,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10034",
			"frame": {"x":264,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10035",
			"frame": {"x":264,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "st.png",
			"format": "RGB8",
			"size": {"w":334,"h":479},
			"scale": "1"
		}
		},
	speakerJson : {"frames": [

		{
			"filename": "Symbol 5 instance 10000",
			"frame": {"x":0,"y":0,"w":41,"h":30},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":30},
			"sourceSize": {"w":41,"h":30}
		},
		{
			"filename": "Symbol 5 instance 10001",
			"frame": {"x":0,"y":30,"w":41,"h":30},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":30},
			"sourceSize": {"w":41,"h":30}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "s.png",
			"format": "RGB8",
			"size": {"w":44,"h":64},
			"scale": "1"
		}
	},

	btnJson : {"frames": [

{
	"filename": "Symbol 1 instance 10000",
	"frame": {"x":0,"y":0,"w":212,"h":71},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":212,"h":71},
	"sourceSize": {"w":212,"h":71}
}
,{
	"filename": "Symbol 1 instance 10001",
	"frame": {"x":0,"y":71,"w":212,"h":71},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":212,"h":71},
	"sourceSize": {"w":212,"h":71}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "16.5.1.104",
	"image": "b1.png",
	"format": "RGB8",
	"size": {"w":213,"h":144},
	"scale": "1"
}
},

	replyJson : {"frames": [

{
	"filename": "Symbol 8 instance 10000",
	"frame": {"x":0,"y":0,"w":47,"h":47},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":47,"h":47},
	"sourceSize": {"w":47,"h":47}
}
,{
	"filename": "Symbol 8 instance 10001",
	"frame": {"x":47,"y":0,"w":47,"h":47},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":47,"h":47},
	"sourceSize": {"w":47,"h":47}
}
,{
	"filename": "Symbol 8 instance 10002",
	"frame": {"x":0,"y":0,"w":47,"h":47},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":47,"h":47},
	"sourceSize": {"w":47,"h":47}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "15.1.0.210",
	"image": "Back btn.png",
	"format": "RGBA8888",
	"size": {"w":98,"h":48},
	"scale": "1"
}
},

    backbtnJson : {"frames": [

		{
			"filename": "Symbol 9 instance 10000",
			"frame": {"x":0,"y":0,"w":41,"h":29},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":29},
			"sourceSize": {"w":41,"h":29}
		}
		,{
			"filename": "Symbol 9 instance 10001",
			"frame": {"x":0,"y":29,"w":41,"h":29},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":29},
			"sourceSize": {"w":41,"h":29}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "back.png",
			"format": "RGB8",
			"size": {"w":44,"h":64},
			"scale": "1"
		}
		},

    tickJson : {"frames": [

{
	"filename": "Symbol 14 copy instance 10000",
	"frame": {"x":0,"y":0,"w":58,"h":61},
	"rotated": false,
	"trimmed": true,
	"spriteSourceSize": {"x":0,"y":0,"w":64,"h":68},
	"sourceSize": {"w":64,"h":68}
}
,{
	"filename": "Symbol 14 copy instance 10001",
	"frame": {"x":58,"y":0,"w":59,"h":62},
	"rotated": false,
	"trimmed": true,
	"spriteSourceSize": {"x":5,"y":6,"w":64,"h":68},
	"sourceSize": {"w":64,"h":68}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "15.1.0.210",
	"image": "right btn.png",
	"format": "RGB8",
	"size": {"w":121,"h":62},
	"scale": "1"
}
},
    
jumpingWaterJson: {"frames": [

{
	"filename": "Symbol 4 instance 10000",
	"frame": {"x":0,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10001",
	"frame": {"x":58,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10002",
	"frame": {"x":116,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10003",
	"frame": {"x":174,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10004",
	"frame": {"x":232,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10005",
	"frame": {"x":290,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10006",
	"frame": {"x":348,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10007",
	"frame": {"x":406,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10008",
	"frame": {"x":464,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10009",
	"frame": {"x":522,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10010",
	"frame": {"x":580,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10011",
	"frame": {"x":638,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10012",
	"frame": {"x":696,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Kingfisher jum anim.png",
	"format": "RGBA8888",
	"size": {"w":758,"h":61},
	"scale": "1"
}
},
    
numberpadJson: {"frames": [

{
	"filename": "Symbol 3 instance 10000",
	"frame": {"x":0,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10001",
	"frame": {"x":68,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10002",
	"frame": {"x":136,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10003",
	"frame": {"x":204,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10004",
	"frame": {"x":272,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10005",
	"frame": {"x":340,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10006",
	"frame": {"x":408,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10007",
	"frame": {"x":476,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10008",
	"frame": {"x":544,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10009",
	"frame": {"x":612,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10010",
	"frame": {"x":680,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10011",
	"frame": {"x":748,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10012",
	"frame": {"x":816,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10013",
	"frame": {"x":884,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "number 0 to 9.png",
	"format": "RGBA8888",
	"size": {"w":952,"h":68},
	"scale": "1"
}
},

ScreenTextBox: {"frames": [

{
	"filename": "Symbol 14 instance 10000",
	"frame": {"x":0,"y":0,"w":159,"h":87},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":159,"h":87},
	"sourceSize": {"w":159,"h":87}
}
,{
	"filename": "Symbol 14 instance 10001",
	"frame": {"x":159,"y":0,"w":159,"h":87},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":159,"h":87},
	"sourceSize": {"w":159,"h":87}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "19.2.1.408",
	"image": "Box2.png.png",
	"format": "RGBA8888",
	"size": {"w":319,"h":87},
	"scale": "1"
}
},

comingUpJson: {"frames": [
{
	"filename": "Symbol 4 copy instance 10000",
	"frame": {"x":0,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10001",
	"frame": {"x":68,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10002",
	"frame": {"x":136,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10003",
	"frame": {"x":204,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10004",
	"frame": {"x":272,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10005",
	"frame": {"x":340,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10006",
	"frame": {"x":408,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10007",
	"frame": {"x":476,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10008",
	"frame": {"x":544,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10009",
	"frame": {"x":612,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10010",
	"frame": {"x":680,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10011",
	"frame": {"x":748,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10012",
	"frame": {"x":816,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "holding a fish coming back from water,.png",
	"format": "RGBA8888",
	"size": {"w":918,"h":72},
	"scale": "1"
}    
    
},
    
kingfisherhoveringJson: {"frames": [

{
	"filename": "Symbol 5 instance 10000",
	"frame": {"x":0,"y":0,"w":96,"h":122},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":96,"h":122},
	"sourceSize": {"w":96,"h":122}
}
,{
	"filename": "Symbol 5 instance 10001",
	"frame": {"x":96,"y":0,"w":96,"h":122},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":96,"h":122},
	"sourceSize": {"w":96,"h":122}
}
,{
	"filename": "Symbol 5 instance 10002",
	"frame": {"x":192,"y":0,"w":96,"h":122},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":96,"h":122},
	"sourceSize": {"w":96,"h":122}
}
,{
	"filename": "Symbol 5 instance 10003",
	"frame": {"x":288,"y":0,"w":96,"h":122},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":96,"h":122},
	"sourceSize": {"w":96,"h":122}
}
,{
	"filename": "Symbol 5 instance 10004",
	"frame": {"x":384,"y":0,"w":96,"h":122},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":96,"h":122},
	"sourceSize": {"w":96,"h":122}
}
,{
	"filename": "Symbol 5 instance 10005",
	"frame": {"x":480,"y":0,"w":96,"h":122},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":96,"h":122},
	"sourceSize": {"w":96,"h":122}
}
,{
	"filename": "Symbol 5 instance 10006",
	"frame": {"x":576,"y":0,"w":96,"h":122},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":96,"h":122},
	"sourceSize": {"w":96,"h":122}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Kingfisher hovering.png",
	"format": "RGBA8888",
	"size": {"w":674,"h":138},
	"scale": "1"
}
},
    
eatingfishJson:{"frames": [

{
	"filename": "Symbol 1 copy 3 instance 10000",
	"frame": {"x":0,"y":0,"w":40,"h":35},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":35},
	"sourceSize": {"w":40,"h":35}
}
,{
	"filename": "Symbol 1 copy 3 instance 10001",
	"frame": {"x":40,"y":0,"w":40,"h":35},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":35},
	"sourceSize": {"w":40,"h":35}
}
,{
	"filename": "Symbol 1 copy 3 instance 10002",
	"frame": {"x":80,"y":0,"w":40,"h":35},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":35},
	"sourceSize": {"w":40,"h":35}
}
,{
	"filename": "Symbol 1 copy 3 instance 10003",
	"frame": {"x":120,"y":0,"w":40,"h":35},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":35},
	"sourceSize": {"w":40,"h":35}
}
,{
	"filename": "Symbol 1 copy 3 instance 10004",
	"frame": {"x":160,"y":0,"w":40,"h":35},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":35},
	"sourceSize": {"w":40,"h":35}
}
,{
	"filename": "Symbol 1 copy 3 instance 10005",
	"frame": {"x":200,"y":0,"w":40,"h":35},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":35},
	"sourceSize": {"w":40,"h":35}
}
,{
	"filename": "Symbol 1 copy 3 instance 10006",
	"frame": {"x":240,"y":0,"w":40,"h":35},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":35},
	"sourceSize": {"w":40,"h":35}
}
,{
	"filename": "Symbol 1 copy 3 instance 10007",
	"frame": {"x":280,"y":0,"w":40,"h":35},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":35},
	"sourceSize": {"w":40,"h":35}
}
,{
	"filename": "Symbol 1 copy 3 instance 10008",
	"frame": {"x":320,"y":0,"w":40,"h":35},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":35},
	"sourceSize": {"w":40,"h":35}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Kingfisher Eating Fish.png",
	"format": "RGBA8888",
	"size": {"w":366,"h":35},
	"scale": "1"
}
},


bubblesJson: {"frames": [

{
	"filename": "Symbol 12 instance 10000",
	"frame": {"x":0,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10001",
	"frame": {"x":60,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10002",
	"frame": {"x":120,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10003",
	"frame": {"x":180,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10004",
	"frame": {"x":240,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10005",
	"frame": {"x":300,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10006",
	"frame": {"x":360,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10007",
	"frame": {"x":420,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10008",
	"frame": {"x":480,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10009",
	"frame": {"x":540,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10010",
	"frame": {"x":600,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10011",
	"frame": {"x":660,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10012",
	"frame": {"x":720,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10013",
	"frame": {"x":780,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10014",
	"frame": {"x":840,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10015",
	"frame": {"x":900,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10016",
	"frame": {"x":960,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10017",
	"frame": {"x":1020,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10018",
	"frame": {"x":1080,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10019",
	"frame": {"x":1140,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10020",
	"frame": {"x":1200,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10021",
	"frame": {"x":1260,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10022",
	"frame": {"x":1320,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10023",
	"frame": {"x":1380,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10024",
	"frame": {"x":0,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10025",
	"frame": {"x":60,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10026",
	"frame": {"x":120,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10027",
	"frame": {"x":180,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10028",
	"frame": {"x":240,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10029",
	"frame": {"x":300,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10030",
	"frame": {"x":360,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10031",
	"frame": {"x":420,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10032",
	"frame": {"x":480,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10033",
	"frame": {"x":540,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10034",
	"frame": {"x":600,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10035",
	"frame": {"x":660,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10036",
	"frame": {"x":720,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10037",
	"frame": {"x":780,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10038",
	"frame": {"x":840,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10039",
	"frame": {"x":900,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Bubble anim.png",
	"format": "RGBA8888",
	"size": {"w":1458,"h":275},
	"scale": "1"
}
},

insideWaterJson: {"frames": [

{
	"filename": "Symbol 4 instance 10000",
	"frame": {"x":0,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10001",
	"frame": {"x":58,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10002",
	"frame": {"x":116,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10003",
	"frame": {"x":174,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10004",
	"frame": {"x":232,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10005",
	"frame": {"x":290,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10006",
	"frame": {"x":348,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10007",
	"frame": {"x":406,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10008",
	"frame": {"x":464,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10009",
	"frame": {"x":522,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10010",
	"frame": {"x":580,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10011",
	"frame": {"x":638,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}
,{
	"filename": "Symbol 4 instance 10012",
	"frame": {"x":696,"y":0,"w":58,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":58,"h":58},
	"sourceSize": {"w":58,"h":58}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Kingfisher jum under Water.png",
	"format": "RGBA8888",
	"size": {"w":766,"h":64},
	"scale": "1"
}
},
    

comingupWaterJson: {"frames": [

{
	"filename": "Symbol 4 copy instance 10000",
	"frame": {"x":0,"y":0,"w":67,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":67,"h":65},
	"sourceSize": {"w":67,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10001",
	"frame": {"x":67,"y":0,"w":67,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":67,"h":65},
	"sourceSize": {"w":67,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10002",
	"frame": {"x":134,"y":0,"w":67,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":67,"h":65},
	"sourceSize": {"w":67,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10003",
	"frame": {"x":201,"y":0,"w":67,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":67,"h":65},
	"sourceSize": {"w":67,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10004",
	"frame": {"x":268,"y":0,"w":67,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":67,"h":65},
	"sourceSize": {"w":67,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10005",
	"frame": {"x":335,"y":0,"w":67,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":67,"h":65},
	"sourceSize": {"w":67,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10006",
	"frame": {"x":402,"y":0,"w":67,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":67,"h":65},
	"sourceSize": {"w":67,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10007",
	"frame": {"x":469,"y":0,"w":67,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":67,"h":65},
	"sourceSize": {"w":67,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10008",
	"frame": {"x":536,"y":0,"w":67,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":67,"h":65},
	"sourceSize": {"w":67,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10009",
	"frame": {"x":603,"y":0,"w":67,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":67,"h":65},
	"sourceSize": {"w":67,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10010",
	"frame": {"x":670,"y":0,"w":67,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":67,"h":65},
	"sourceSize": {"w":67,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10011",
	"frame": {"x":737,"y":0,"w":67,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":67,"h":65},
	"sourceSize": {"w":67,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10012",
	"frame": {"x":804,"y":0,"w":67,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":67,"h":65},
	"sourceSize": {"w":67,"h":65}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Kingfisher Return to under Water.png",
	"format": "RGBA8888",
	"size": {"w":883,"h":65},
	"scale": "1"
}
},

SplashWater: {"frames": [

{
	"filename": "Symbol 1 copy 4 instance 10000",
	"frame": {"x":0,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10001",
	"frame": {"x":320,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10002",
	"frame": {"x":640,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10003",
	"frame": {"x":960,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10004",
	"frame": {"x":1280,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10005",
	"frame": {"x":1600,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10006",
	"frame": {"x":1920,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10007",
	"frame": {"x":2240,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10008",
	"frame": {"x":2560,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10009",
	"frame": {"x":2880,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10010",
	"frame": {"x":3200,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10011",
	"frame": {"x":3520,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10012",
	"frame": {"x":3840,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10013",
	"frame": {"x":4160,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Water splash anim.png",
	"format": "RGBA8888",
	"size": {"w":4500,"h":167},
	"scale": "1"
}
},

homebtnJson: {"frames": [

{
	"filename": "Symbol 4 instance 10000",
	"frame": {"x":0,"y":0,"w":60,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
	"sourceSize": {"w":60,"h":60}
}
,{
	"filename": "Symbol 4 instance 10001",
	"frame": {"x":0,"y":60,"w":60,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
	"sourceSize": {"w":60,"h":60}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "18.0.1.115",
	"image": "H.png",
	"format": "RGB8",
	"size": {"w":64,"h":128},
	"scale": "1"
}
},
    
nextbtnJson: {"frames": [

{
	"filename": "Symbol 6 instance 10000",
	"frame": {"x":0,"y":0,"w":59,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":59,"h":60},
	"sourceSize": {"w":59,"h":60}
}
,{
	"filename": "Symbol 6 instance 10001",
	"frame": {"x":0,"y":60,"w":59,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":59,"h":60},
	"sourceSize": {"w":59,"h":60}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "18.0.1.115",
	"image": "N.png",
	"format": "RGB8",
	"size": {"w":64,"h":128},
	"scale": "1"
}
},

Fish_1: {"frames": [

{
	"filename": "Symbol 8 copy 2 instance 10000",
	"frame": {"x":0,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}
,{
	"filename": "Symbol 8 copy 2 instance 10001",
	"frame": {"x":121,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}
,{
	"filename": "Symbol 8 copy 2 instance 10002",
	"frame": {"x":242,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}
,{
	"filename": "Symbol 8 copy 2 instance 10003",
	"frame": {"x":363,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}
,{
	"filename": "Symbol 8 copy 2 instance 10004",
	"frame": {"x":484,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}
,{
	"filename": "Symbol 8 copy 2 instance 10005",
	"frame": {"x":605,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}
,{
	"filename": "Symbol 8 copy 2 instance 10006",
	"frame": {"x":726,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}
,{
	"filename": "Symbol 8 copy 2 instance 10007",
	"frame": {"x":847,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}
,{
	"filename": "Symbol 8 copy 2 instance 10008",
	"frame": {"x":968,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}
,{
	"filename": "Symbol 8 copy 2 instance 10009",
	"frame": {"x":1089,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}
,{
	"filename": "Symbol 8 copy 2 instance 10010",
	"frame": {"x":1210,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}
,{
	"filename": "Symbol 8 copy 2 instance 10011",
	"frame": {"x":1331,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}
,{
	"filename": "Symbol 8 copy 2 instance 10012",
	"frame": {"x":1452,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}
,{
	"filename": "Symbol 8 copy 2 instance 10013",
	"frame": {"x":1573,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}
,{
	"filename": "Symbol 8 copy 2 instance 10014",
	"frame": {"x":1694,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}
,{
	"filename": "Symbol 8 copy 2 instance 10015",
	"frame": {"x":1815,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}
,{
	"filename": "Symbol 8 copy 2 instance 10016",
	"frame": {"x":1936,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}
,{
	"filename": "Symbol 8 copy 2 instance 10017",
	"frame": {"x":2057,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}
,{
	"filename": "Symbol 8 copy 2 instance 10018",
	"frame": {"x":2178,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}
,{
	"filename": "Symbol 8 copy 2 instance 10019",
	"frame": {"x":2299,"y":0,"w":121,"h":74},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":121,"h":74},
	"sourceSize": {"w":121,"h":74}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Fish 2 anim.png",
	"format": "RGBA8888",
	"size": {"w":2433,"h":80},
	"scale": "1"
}
},

level_scale: {"frames": [

{
	"filename": "Symbol 2 instance 10000",
	"frame": {"x":0,"y":0,"w":53,"h":429},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":53,"h":429},
	"sourceSize": {"w":53,"h":429}
}
,{
	"filename": "Symbol 2 instance 10001",
	"frame": {"x":53,"y":0,"w":53,"h":429},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":53,"h":429},
	"sourceSize": {"w":53,"h":429}
}
,{
	"filename": "Symbol 2 instance 10002",
	"frame": {"x":106,"y":0,"w":53,"h":429},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":53,"h":429},
	"sourceSize": {"w":53,"h":429}
}
,{
	"filename": "Symbol 2 instance 10003",
	"frame": {"x":159,"y":0,"w":53,"h":429},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":53,"h":429},
	"sourceSize": {"w":53,"h":429}
}
,{
	"filename": "Symbol 2 instance 10004",
	"frame": {"x":212,"y":0,"w":53,"h":429},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":53,"h":429},
	"sourceSize": {"w":53,"h":429}
}
,{
	"filename": "Symbol 2 instance 10005",
	"frame": {"x":265,"y":0,"w":53,"h":429},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":53,"h":429},
	"sourceSize": {"w":53,"h":429}
}
,{
	"filename": "Symbol 2 instance 10006",
	"frame": {"x":318,"y":0,"w":53,"h":429},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":53,"h":429},
	"sourceSize": {"w":53,"h":429}
}
,{
	"filename": "Symbol 2 instance 10007",
	"frame": {"x":371,"y":0,"w":53,"h":429},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":53,"h":429},
	"sourceSize": {"w":53,"h":429}
}
,{
	"filename": "Symbol 2 instance 10008",
	"frame": {"x":424,"y":0,"w":53,"h":429},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":53,"h":429},
	"sourceSize": {"w":53,"h":429}
}
,{
	"filename": "Symbol 2 instance 10009",
	"frame": {"x":477,"y":0,"w":53,"h":429},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":53,"h":429},
	"sourceSize": {"w":53,"h":429}
}
,{
	"filename": "Symbol 2 instance 10010",
	"frame": {"x":530,"y":0,"w":53,"h":429},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":53,"h":429},
	"sourceSize": {"w":53,"h":429}
}
,{
	"filename": "Symbol 2 instance 10011",
	"frame": {"x":583,"y":0,"w":53,"h":429},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":53,"h":429},
	"sourceSize": {"w":53,"h":429}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Scale anim.png",
	"format": "RGBA8888",
	"size": {"w":641,"h":430},
	"scale": "1"
}
},
};

